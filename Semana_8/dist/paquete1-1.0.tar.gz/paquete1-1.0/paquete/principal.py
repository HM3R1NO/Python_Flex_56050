from clase import Alumno

alumno = Alumno("Emanuel",7)
alumno.imprimir()